# TortoiseMerge Portable 1.8.11.26392
## What's this?
* "TortoiseMerge Portable" is pseudo portable version TortoiseMerge based TortoiseSVN 1.8.11.26392.
* Binaries are extract from original version TortoiseSVN binary distribution. http://sourceforge.net/projects/tortoisesvn/files/1.8.11/Application/
## How to use
1. Download and extract files.
2. Choose x86 or x64 folder.
3. Copy files into your target folder.
## How to enable auto-detect from SourceTree:
1. Edit "HKLM.reg". Replace "TMergePath" value to your placed "TortoiseMerge.exe" path.
2. Execute "HKLM.reg".
## Enjoy!
